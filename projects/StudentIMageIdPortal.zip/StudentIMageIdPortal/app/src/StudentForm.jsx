// React Component: StudentForm.jsx

import React, { useState } from "react";
import axios from "axios";

const StudentForm = () => {
  const [formData, setFormData] = useState({
    name: "",
    surname: "",
    age: "",
    email: "",
    phone: "",
    studentId: ""
  });

  const [image, setImage] = useState(null);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleImageChange = (e) => {
    //  const selectedFiles = Array.from(e.target.files);
    //to ensure that to select only 5 images
    // if (selectedFiles.length > 5) {
    //   alert("You can upload a maximum of 5 images.");
    //   e.target.value = ""; // Clear the input
    //   return;
    // }
    // setImage(e.target.files);
//     for (let f of e.target.files) {
//   if (f.size > 1 * 1024 * 1024) {
//     alert(`${f.name} is larger than 5MB`);
//     return;
//   }
// }

    setImage(e.target.files[0]);//to accept only first selected image ignoring other images
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = new FormData();
    for (let key in formData) 
      {
      data.append(key, formData[key]);
      console.log(key)
      // console.log(formData(key))
    }
    if (image) 
    {
      data.append("image", image);
    }
    console.log(image)
    try {
      const response = await axios.post("http://localhost:8080/student/register", data);
      alert("Student submitted successfully!");
    } catch (error) {
      alert("Error submitting student: " + error.message);
    }
  };

  return (
    <div className="form-container">
      <h2>Student Registration</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" name="name" placeholder="Name" onChange={handleChange} required /><br/>
        <input type="text" name="surname" placeholder="Surname" onChange={handleChange} required /><br/>
        <input type="number" name="age" placeholder="Age" onChange={handleChange} required /><br/>
        <input type="email" name="email" placeholder="Email" onChange={handleChange} required /><br/>
        <input type="text" name="phone" placeholder="Phone" onChange={handleChange} required /><br/>
        <input type="text" name="studentId" placeholder="Student ID" onChange={handleChange} required /><br/>
        <input type="file"  accept="image/*" onChange={handleImageChange} required /><br/>
          {/* <input type="file" multiple accept="image/*" onChange={handleImageChange} required /><br/> */}
        {/* <input type="file"  onChange={handleImageChange} required /><br/> ALL files can be selected */}
        {/* <input type="file" accept=".doc,.docx,.pdf" onChange={handleImageChange} required /><br/> */}
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default StudentForm;


// ❓ Why files[0] in this line:
// setImage(e.target.files[0]);
// ✅ Explanation:
// When you use <input type="file" />, the browser allows the user to select one or more files.

// e.target.files is a FileList object, like an array of selected files.

// Since you're allowing only one image upload, you get the first file using:

// e.target.files[0]
// 📦 What’s Inside files[0]?
// It contains:

// {
//   name: "uv_photo.png",
//   size: 34256,
//   type: "image/png",
//   lastModified: 1719572940000
// }
// So when you send it with FormData, it behaves like:

// formData.append("image", files[0]);
// ❓ Why this line:

// <input type="file" accept="image/*" />
// ✅ Explanation:
// accept="image/*" tells the browser to only allow image files (like .jpg, .png, .webp, .jpeg).

// The * is a wildcard — it means “all image types.”

// So if the user tries to upload a .pdf or .mp3, it won’t even show them those options in the file picker.

// ✅ It's a good UX filter to guide the user before they make a mistake.

// 🔄 Summary:
// Line	Why It’s Used
// files[0]	To grab the first file user uploaded
// accept="image/*"	To limit uploads to only images like JPG/PNG







// ❌ Why we can’t just send the form directly as JSON when uploading an image:
// 👉 JSON can’t handle binary/image data
// JSON supports strings, numbers, booleans, arrays, and objects.

// But it cannot directly store files like images.

// If you try:


// const payload = {
//   name: "Upendra",
//   image: imageFile  // 🚫 This is not serializable
// };
// axios.post("/student/register", payload); // ❌ won't work properly
// 🛑 Result: imageFile will be sent as [object Object], and backend won’t receive the file.

// ✅ Why we use FormData instead
// 📦 FormData is specially designed for:
// Sending form fields + files (images) in one request

// Using multipart/form-data content type

// Browser handles file encoding (base64, boundaries, etc.) behind the scenes

// Example:

// const data = new FormData();
// data.append("name", "Upendra");
// data.append("image", imageFile); // this is binary file
// And then:

// axios.post("/student/register", data);
// 🧠 Backend can receive it using:

// @RequestParam("name") String name,
// @RequestParam("image") MultipartFile image
// 🔄 Summary
// Sending Method	Supports Image?	Used For
// JSON.stringify({})	❌ No	Normal API data (text only)
// FormData	✅ Yes	File + field uploads



//===========================================================================================
//===========================================================================================
// 🔍 1. What type of files can you select?
// By default:
// If you don't specify any restrictions, users can select any file type — images, PDFs, Word documents, videos, text files, etc.

// ✅ Examples of selectable file types:

// .jpg, .png, .gif

// .pdf

// .doc, .docx

// .txt

// .mp4, .mov

// .zip, .exe, etc.

// ✅ How to restrict file types (optional)?
// You can use the accept attribute to allow only certain types:

// <input type="file" multiple accept="image/*" />
// ✅ Examples of accept usage:

// accept="image/*"               // Only images
// accept=".pdf"                  // Only PDF
// accept=".doc,.docx,.pdf"       // Only DOC, DOCX, PDF
// accept="video/*"               // Only videos
// 🔢 2. How many files can be selected?
// By default:

// There's no limit in the browser itself on how many files you can select when multiple is used.

// But in practice:

// The limit is usually controlled by backend settings or server configurations.

// You can manually restrict it in frontend like:

// if (files.length > 10) {
//   alert("You can only upload up to 10 files");
//   return;
// }
// 📏 3. What is the max size of files?
// By default:

// There is no size restriction in HTML or JavaScript.

// BUT:

// Browsers may crash or freeze if very large files (like 1GB+) are selected.

// Backend server limits apply, for example:

// In Spring Boot, the max file size is usually controlled by:

// spring.servlet.multipart.max-file-size=10MB
// spring.servlet.multipart.max-request-size=20MB
// You can increase or reduce it as per your needs.

// You can also prevent large files on frontend like this:


// for (let f of files) {
//   if (f.size > 5 * 1024 * 1024) {
//     alert(`${f.name} is larger than 5MB`);
//     return;
//   }
// }
// ✅ Summary:
// Question	Answer
// What file types allowed?	All types unless accept attribute restricts it
// How many files can be selected?	Unlimited (frontend/backend can limit it)
// Max file size?	Controlled by backend config (multipart.max-file-size) or frontend check

