import AdminDashboard from "./AdminDashboard";
import ProductForm from "./ProductForm";
import ProductGrid from "./ProductGrid";
import StudentForm from "./StudentForm";
import { BrowserRouter, Routes, Route } from "react-router-dom"; // ✅ Correct import


function App() {
  return (
    <BrowserRouter> {/* ✅ Router should wrap everything */}
      <Routes>
        <Route path="/" element={<StudentForm />} /> {/* ✅ Route for student form */}
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/productform" element={<ProductForm />} />
        <Route path="/productgrid" element={<ProductGrid />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
