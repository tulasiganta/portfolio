import React, { useState } from 'react';
import axios from 'axios';

function ProductForm({ onProductAdded }) {
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [quantity, setQuantity] = useState('');
  const [images, setImages] = useState([]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = new FormData();

    data.append('name', name);
    data.append('price', price);
    data.append('quantity', quantity);
    for (let img of images) {
      data.append('images', img);
    }

    try {
      await axios.post('http://localhost:8080/api/products', data);
      alert('Product added!');
      onProductAdded(); // Refresh product list
    } catch (err) {
      alert('Upload failed');
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: '40px' }}>
      <input placeholder="Product name" value={name} onChange={(e) => setName(e.target.value)} required /><br />
      <input placeholder="Price" value={price} onChange={(e) => setPrice(e.target.value)} required /><br />
      <input placeholder="Quantity" value={quantity} onChange={(e) => setQuantity(e.target.value)} required /><br />
      <input type="file" multiple accept="image/*" onChange={(e) => setImages(e.target.files)} required /><br />
      <button type="submit">Add Product</button>
    </form>
  );
}

export default ProductForm;
