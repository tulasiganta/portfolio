import React, { useEffect, useState } from 'react';
import axios from 'axios';

function ProductGrid() {
  const [products, setProducts] = useState([]);
  const [currentImageIndex, setCurrentImageIndex] = useState({});

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    const res = await axios.get('http://localhost:8080/api/products');
    setProducts(res.data);
    const indexMap = {};
    res.data.forEach(p => (indexMap[p.id] = 0));
    setCurrentImageIndex(indexMap);
  };

  const nextImage = (id, total) => {
    setCurrentImageIndex(prev => ({
      ...prev,
      [id]: (prev[id] + 1) % total,
    }));
  };

  const prevImage = (id, total) => {
    setCurrentImageIndex(prev => ({
      ...prev,
      [id]: (prev[id] - 1 + total) % total,
    }));
  };

  return (
    <div className="dashboard">
      <h2>Product Gallery</h2>
      <div className="student-grid">
        {products.map(product => {
          const currentIndex = currentImageIndex[product.id] || 0;
          const imageList = product.imagePaths || [];
          const currentImage = imageList[currentIndex];

          return (
            <div className="student-card" key={product.id}>
              <div className="carousel-container">
                <button className="arrow left" onClick={() => prevImage(product.id, imageList.length)}>&#8592;</button>
                <img
                  src={`http://localhost:8080/api/products/images/${currentImage}`}
                  alt="product"
                  className="student-img"
                />
                <button className="arrow right" onClick={() => nextImage(product.id, imageList.length)}>&#8594;</button>
              </div>
              <h3>{product.name}</h3>
              <p>Price: ₹{product.price}</p>
              <p>Quantity: {product.quantity}</p>
            </div>
          );
        })}
      </div>

      {/* Embedded CSS */}
      <style>{`
        body {
          margin: 0;
          padding: 0;
          font-family: sans-serif;
        }

        .dashboard {
          width: 100vw;
          min-height: 100vh;
          padding: 30px;
          background: #f0f0f0;
        }

        h2 {
          text-align: center;
          margin-bottom: 30px;
        }

        .student-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 25px;
          padding: 0 20px;
        }

        .student-card {
          background: #fff;
          padding: 20px;
          border-radius: 10px;
          text-align: center;
          box-shadow: 0 4px 12px rgba(0,0,0,0.1);
          transition: transform 0.3s;
          position: relative;
        }

        .student-card:hover {
          transform: translateY(-5px);
        }

        .carousel-container {
          position: relative;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .student-img {
          width: 120px;
          height: 120px;
          border-radius: 50%;
          object-fit: cover;
          margin-bottom: 10px;
          border: 2px solid #ccc;
        }

        .arrow {
          position: absolute;
          background: rgba(0,0,0,0.5);
          color: #fff;
          border: none;
          font-size: 20px;
          width: 30px;
          height: 30px;
          border-radius: 50%;
          cursor: pointer;
          top: 50%;
          transform: translateY(-50%);
        }

        .arrow.left {
          left: -10px;
        }

        .arrow.right {
          right: -10px;
        }

        .arrow:hover {
          background: #000;
        }
      `}</style>
    </div>
  );
}

export default ProductGrid;
