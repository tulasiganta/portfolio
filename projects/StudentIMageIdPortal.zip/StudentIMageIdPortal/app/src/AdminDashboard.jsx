// // src/AdminDashboard.jsx
// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import "./App.css";

// const AdminDashboard = () => {
//   const [students, setStudents] = useState([]);

//   useEffect(() => {
//     fetchStudents();
//   }, []);

//   const fetchStudents = async () => {
//     try {
//       const response = await axios.get("http://localhost:8080/admin/students");
//       const sorted = response.data.sort((a, b) =>
//         a.studentId.localeCompare(b.studentId)
//       );
//       setStudents(sorted);
//     } catch (error) {
//       console.error("Failed to fetch students:", error);
//     }
//   };

//   return (
//     <div className="dashboard">
//       <h2>Admin Dashboard - Student List</h2>
//       <div className="student-grid">
//         {students.map((student) => (
//           <div key={student.id} className="student-card">
//             <img
//               src={`http://localhost:8080/images/${student.imagePath}`}
//               alt="Profile"
//               className="student-img"
//             />
//             <h4>
//               {student.name} {student.surname}
//             </h4>
//             <p>ID: {student.studentId}</p>
//             <p>Age: {student.age}</p>
//             <p>Email: {student.email}</p>
//             <p>Phone: {student.phone}</p>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default AdminDashboard;






import React, { useEffect, useState } from "react";
import axios from "axios";

const AdminDashboard = () => {
  const [students, setStudents] = useState([]);

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    try {
      const response = await axios.get("http://localhost:8080/admin/students");
      const sorted = response.data.sort((a, b) =>
        a.studentId.localeCompare(b.studentId)
      );
      setStudents(sorted);
    } catch (error) {
      console.error("Failed to fetch students:", error);
    }
  };

  return (
    <>
      {/* Embedded CSS */}
      <style>{`
        body {
          margin: 0;
          padding: 0;
          font-family: sans-serif;
        }

        .dashboard {
          width: 100vw;
          min-height: 100vh;
          padding: 30px;
          background: #f0f0f0;
        }

        h2 {
          text-align: center;
          margin-bottom: 30px;
        }

        .student-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 25px;
          padding: 0 20px;
        }

        .student-card {
          background: #fff;
          padding: 20px;
          border-radius: 10px;
          text-align: center;
          box-shadow: 0 4px 12px rgba(0,0,0,0.1);
          transition: transform 0.3s;
        }

        .student-card:hover {
          transform: translateY(-5px);
        }

        .student-img {
          width: 120px;
          height: 120px;
          border-radius: 50%;
          object-fit: cover;
          margin-bottom: 10px;
          border: 2px solid #ccc;
        }
      `}</style>

      <div className="dashboard">
        <h2>Admin Dashboard - Student List</h2>
        <div className="student-grid">
          {students.map((student) => (
            <div key={student.id} className="student-card">
              <img
                src={`http://localhost:8080/images/${student.imagePath}`}
                alt="Profile"
                className="student-img"
              />
              <h4>
                {student.name} {student.surname}
              </h4>
              <p>ID: {student.studentId}</p>
              <p>Age: {student.age}</p>
              <p>Email: {student.email}</p>
              <p>Phone: {student.phone}</p>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default AdminDashboard;




// 🔍 Let's break it down:
// 🧠 response.data
// This is an array of student objects:

// [
//   { studentId: "C102", name: "Ravi" },
//   { studentId: "A101", name: "Upendra" },
//   { studentId: "B205", name: "Pooja" }
// ]
// ✅ .sort((a, b) => ...)
// This is JavaScript’s built-in array sort method, which sorts elements using a comparison function.

// a and b are two elements from the array being compared.

// The sort function compares every pair (a, b) and arranges them accordingly.

// ✅ .localeCompare()
// This method compares two strings in alphabetical (dictionary) order.

// "A101".localeCompare("B205")  // -1 → A comes before B → no swap
// "B205".localeCompare("A101")  // 1  → B comes after A → swap
// "C102".localeCompare("C102")  // 0  → same → no change
// So this line:

// a.studentId.localeCompare(b.studentId)
// ✅ Tells sort:

// If result is -1 → leave a before b

// If result is 1 → swap a and b

// If result is 0 → keep them as-is

// 🧾 Final Sorted Output:
// [
//   { studentId: "A101", name: "Upendra" },
//   { studentId: "B205", name: "Pooja" },
//   { studentId: "C102", name: "Ravi" }
// ]
// 🧠 Why localeCompare() over a.studentId < b.studentId?
// Handles case sensitivity (A vs a)

// Works with Unicode/locale-aware strings

// More accurate for string-based sorting

// 🔁 Summary Table
// Code	What It Does
// sort((a, b) => ...)	Sorts array using custom logic
// a.studentId.localeCompare(b.studentId)	Compares student IDs alphabetically
// Result	Returns a sorted array of students



// ======================================================================================
// ======================================================================================
// ======================================================================================





// 🔥 Excellent clarity bro! You're asking:

// “In sort((a, b) => ...), when there are many elements in the array, which two elements do a and b point to at each step?”

// Let me visually show you how JavaScript internally calls sort() on a list with multiple elements 👇

// 🧾 Sample Array

// const arr = ["Zebra", "Banana", "Apple"];
// Now we run:

// arr.sort((a, b) => a.localeCompare(b));
// 🔍 What happens internally (comparison steps):
// JavaScript doesn’t compare all items at once — it does pair-wise comparisons.

// Step	a	b	Comparison (a.localeCompare(b))	Result
// 1	"Banana"	"Zebra"	"Banana" < "Zebra" → -1	✅ keep order
// 2	"Apple"	"Banana"	"Apple" < "Banana" → -1	🔁 swap
// 3	"Apple"	"Banana" (again check after swap)	"Apple" < "Banana" → -1	✅ done

// ["Apple", "Banana", "Zebra"]




// ======================================================================================
// ======================================================================================
// ======================================================================================


// CSSSSSSS

// 🔍 Line-by-Line Explanation
// 1️⃣ display: grid;
// Turns the .student-grid container into a CSS Grid layout.

// This allows you to organize .student-card items into rows and columns easily.

// 2️⃣ grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
// This is the most important line! It defines how many columns you want and how they behave.

// ✅ Breakdown:
// repeat(...) → tells the grid to create multiple columns.

// auto-fit → automatically fits as many columns as possible based on container width.

// minmax(250px, 1fr) → each column will be at least 250px, but can grow (1fr) to fill remaining space.

// 📱 Result:
// On wide screens: multiple columns (3, 4, 5 depending on space)

// On narrow screens: fewer columns, automatically adjusts (like 2 or 1 on mobile)

// 🧠 Visual Example:
// If the screen is 1000px wide:

// diff
// Copy
// Edit
// +-------------+-------------+-------------+-------------+
// |  card 1     |  card 2     |  card 3     |  card 4     |
// +-------------+-------------+-------------+-------------+

// If the screen is 600px wide:
// +-------------+-------------+
// |  card 1     |  card 2     |
// +-------------+-------------+

// If it's very narrow:
// +-------------+
// |  card 1     |
// +-------------+
// |  card 2     |
// +-------------+
// 3️⃣ gap: 25px;
// Adds 25px spacing between grid items (both rows and columns).

// Makes the layout clean and well-separated.

// 4️⃣ padding: 0 20px;
// Adds horizontal padding of 20px (left and right) inside the .student-grid container.

// Prevents cards from touching the edge of the screen.

// ✅ Summary:
// Line	Meaning
// display: grid	Enables CSS Grid layout
// grid-template-columns	Responsive column setup that adapts based on screen width
// gap	Adds space between cards
// padding	Adds space on the left/right of the container




// ✅ What are vw and vh in CSS?
// They are CSS units used to size elements relative to the size of the browser viewport (i.e., the visible area of the browser window).

// 📏 vw = Viewport Width
// 1vw = 1% of the width of the browser window.

// 100vw = 100% of the browser window’s width.

// 📌 Example:

// css
// Copy
// Edit
// width: 100vw;
// 👉 Makes the element as wide as the full screen width, regardless of content.

// 📐 vh = Viewport Height
// 1vh = 1% of the height of the browser window.

// 100vh = 100% of the screen height.

// 📌 Example:

// css
// Copy
// Edit
// min-height: 100vh;
// 👉 Makes the element at least as tall as the full height of the screen.

// ✅ Example Use:
// css
// Copy
// Edit
// body {
//   width: 100vw;
//   min-height: 100vh;
//   background: #f0f0f0;
// }
// This ensures the body:

// Stretches to fill the full width and height of the screen

// Useful for full-page layouts, dashboards, or landing pages

// 🧠 Summary Table:
// Unit	Meaning	1 unit equals
// vw	Viewport Width	1% of screen width
// vh	Viewport Height	1% of screen height
// 100vw	Full width of browser	Entire width
// 100vh	Full height of browser	Entire height










