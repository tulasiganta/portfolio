package com.example.StudentIMageportal.controller;


import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.StudentIMageportal.model.Product;
import com.example.StudentIMageportal.repository.ProductRepository;

@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins = "http://localhost:5174")
public class ProductController {



    private final String uploadDir = "uploads/";

    @Autowired
    private ProductRepository productRepo;

    @PostMapping
    public ResponseEntity<?> addProduct(
            @RequestParam String name,
            @RequestParam double price,
            @RequestParam int quantity,
            @RequestParam("images") List<MultipartFile> images) {
        try {
            List<String> imageNames = new ArrayList<>();
            for (MultipartFile img : images) {
                String fileName = UUID.randomUUID() + "_" + img.getOriginalFilename();
                Path path = Paths.get(uploadDir + fileName);
                Files.createDirectories(path.getParent());
                Files.copy(img.getInputStream(), path);
                imageNames.add(fileName);
            }

            Product product = new Product();
            product.setName(name);
            product.setPrice(price);
            product.setQuantity(quantity);
            System.out.println("11111111111111111111Image filenames to save: " + imageNames);
             System.out.println("111111111111111111111111111111111111111111111111111111111111111111111Image filenames to save: " + imageNames);
            product.setImagePaths(imageNames);

            System.out.println("22222222222222222222Saving product: " + product.getName() + " → " + product.getImagePaths());

            productRepo.save(product);

            return ResponseEntity.ok("Product saved");
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error: " + e.getMessage());
        }
    }

   @GetMapping
public List<Product> getAll() {
     System.out.println("11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111112222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222233333333333333333333333333333333333333333333333333333333333333444444444444444444444444444444444444444444444444444444445555555555555555555555555555555555555555555555555555555555555555");
    List<Product> products = productRepo.findAll();
    System.out.println("11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111112222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222233333333333333333333333333333333333333333333333333333333333333444444444444444444444444444444444444444444444444444444445555555555555555555555555555555555555555555555555555555555555555");
    // Debug print to console
    for (Product p : products) {
        System.out.println("Product ID: " + p.getId());
        System.out.println("Name: " + p.getName());
        System.out.println("Price: " + p.getPrice());
        System.out.println("Quantity: " + p.getQuantity());
        System.out.println("Images:");
        if (p.getImagePaths() != null) {
            for (String path : p.getImagePaths()) {
                System.out.println(" - " + path);
            }
        } else {
            System.out.println(" - No images");
        }
        System.out.println("---------------------------");
    }

    return products;
}


    @GetMapping("/images/{filename}")
    public ResponseEntity<Resource> serveImage(@PathVariable String filename) throws MalformedURLException {
        Path path = Paths.get(uploadDir).resolve(filename);
        Resource resource = new UrlResource(path.toUri());
        if (resource.exists() || resource.isReadable()) {
            return ResponseEntity.ok().contentType(MediaType.IMAGE_JPEG).body(resource);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
