package com.example.StudentIMageportal.controller;

// Directory: com.example.studentdashboard.controller

import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.StudentIMageportal.model.Student;
import com.example.StudentIMageportal.repository.StudentRepository;

@RestController
@CrossOrigin(origins = "http://localhost:5174")
public class StudentController {

    @Autowired
    private StudentRepository studentRepository;

    private final String uploadDir = "uploads/";

    @PostMapping("/student/register")
    public ResponseEntity<String> registerStudent(
            @RequestParam("name") String name,
            @RequestParam("surname") String surname,
            @RequestParam("email") String email,
            @RequestParam("phone") String phone,
            @RequestParam("age") int age,
            @RequestParam("studentId") String studentId,
            @RequestParam("image") MultipartFile imageFile
    ) {
        try {
            // UUI => Universally Unique Identifier
            String fileName = UUID.randomUUID() + "_" + imageFile.getOriginalFilename();
            Path path = Paths.get(uploadDir + fileName);
            Files.createDirectories(path.getParent());
            Files.copy(imageFile.getInputStream(), path);

            Student student = new Student();
            student.setName(name);
            student.setSurname(surname);
            student.setEmail(email);
            student.setPhone(phone);
            student.setAge(age);
            student.setStudentId(studentId);
            student.setImagePath(fileName);

            studentRepository.save(student);

            return ResponseEntity.ok("Student registered successfully.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + e.getMessage());
        }
    }

    @GetMapping("/admin/students")
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    @GetMapping("/images/{filename}")
    public ResponseEntity<Resource> getImage(@PathVariable String filename) throws MalformedURLException {
        Path path = Paths.get(uploadDir).resolve(filename);
        // Uniform Resource Identifier
        Resource resource = new UrlResource(path.toUri());

        return ResponseEntity.ok()
                .contentType(MediaType.IMAGE_JPEG)
                .body(resource);
    }
} 


// // @RequestParam("image") MultipartFile imageFile
// // Here, MultipartFile is a special type in Spring that handles file uploads — like images, PDFs, etc. — coming from a frontend (HTML/React) as part of a multipart/form-data request.


// 🔹 1. String fileName = UUID.randomUUID() + "_" + imageFile.getOriginalFilename();
// ✅ What it does:
// UUID.randomUUID() → generates a random unique string like 9a4c75ef-dbc3-45ee-93d0-1a287fc7b0a1

// imageFile.getOriginalFilename() → gets the name of the uploaded file, e.g., "photo.jpg"

// + "_" + → connects both with underscore to avoid name clashes

// ✅ Example output:
// arduino
// Copy
// Edit
// "9a4c75ef-dbc3-45ee-93d0-1a287fc7b0a1_photo.jpg"
// 🤔 Why?
// This ensures two students don’t overwrite each other's image even if both upload photo.jpg.

// 🔶 1. Path path = Paths.get(uploadDir + fileName);
// What it does:
// It creates a Path object (from java.nio.file.Path) representing the target file location where the uploaded file will be saved.

// uploadDir is typically a directory path string, like "uploads/".

// fileName is something like "d80c1dfe-294f-4a67-80f9-image.jpg" (with UUID to avoid name conflicts).

// Example:
// java
// Copy
// Edit
// String uploadDir = "uploads/";
// String fileName = "abc.jpg";
// Path path = Paths.get("uploads/abc.jpg");
// 🔶 2. Files.createDirectories(path.getParent());
// What it does:
// Ensures that the directory where you want to store the file exists.

// If the directory does not exist, it creates it.

// path.getParent() extracts just the folder from the full path (excluding the filename).

// Example:
// java
// Copy
// Edit
// // If path = "uploads/abc.jpg"
// path.getParent() → "uploads"

// // If uploads/ doesn't exist, create it
// Why needed:
// So that saving the file doesn't fail due to missing folders.

// 🔶 3. Files.copy(imageFile.getInputStream(), path);
// What it does:
// Reads the contents of the uploaded file using imageFile.getInputStream()

// Saves it to the specified location (path) on your disk.

// Example:
// java
// Copy
// Edit
// InputStream in = imageFile.getInputStream();
// Files.copy(in, Paths.get("uploads/abc.jpg"));
// Optional: Prevent overwriting
// If you want to avoid overwriting an existing file, add:

// java
// Copy
// Edit
// Files.copy(imageFile.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
// ✅ Summary in Simple Words
// Line	What it does
// Paths.get(...)	Creates the file path (e.g., uploads/image.jpg)
// Files.createDirectories(...)	Makes sure the uploads/ folder exists
// Files.copy(...)	Writes the uploaded file to that location



//===============================================================================================
//===============================================================================================
//===========================================================================================
//===========================================================================================
// ✅ 1. Path file = Paths.get(uploadDir).resolve(filename);
// What it does:

// Combines the upload directory (uploadDir) with the filename to create a complete file path.

// Example:
// If:

// java
// Copy
// Edit
// String uploadDir = "uploads/";
// String filename = "ravi123_photo.jpg";
// Then:

// java
// Copy
// Edit
// Paths.get("uploads/").resolve("ravi123_photo.jpg")
// becomes:

// pgsql
// Copy
// Edit
// Path to → uploads/ravi123_photo.jpg

// ✅ 2. Resource resource = new UrlResource(file.toUri());
// What it does:

// Converts the file path into a Resource object.

// file.toUri() gets a file URI like file:///C:/projects/uploads/ravi123_photo.jpg

// UrlResource is a Spring class that can serve files via URLs.

// 💡 This makes it easy for Spring Boot to send the file back in the HTTP response.

// ✅ 3. if (resource.exists() || resource.isReadable())
// What it does:

// Checks whether:

// the file actually exists, and

// it can be read (i.e., not locked or corrupted).

// If both conditions are false (file missing or broken), the method should return 404 Not Found.

// ✅ 4. ResponseEntity.ok().contentType(...).body(resource);
// This sends the actual file back to the browser as the response.

// Breakdown:
// .ok() → HTTP 200 response

// .contentType(MediaType.IMAGE_JPEG) → Tells the browser it’s an image (JPEG)

// .body(resource) → Sends the file content as the body

// ✅ 🔄 What happens in the browser?
// When your frontend does:

// jsx
// Copy
// Edit
// <img src={`http://localhost:8080/images/ravi123_photo.jpg`} />
// ✔️ The browser sends a GET request to your Spring Boot /images/{filename} endpoint
// ✔️ Spring loads the file from disk
// ✔️ Sends it back with Content-Type: image/jpeg
// ✔️ The browser displays the image

// Optional Enhancement (Dynamic content type):
// java
// Copy
// Edit
// String contentType = Files.probeContentType(file);
// return ResponseEntity.ok()
//     .contentType(MediaType.parseMediaType(contentType))
//     .body(resource);
// This way, you don’t have to hardcode IMAGE_JPEG. It could return image/png, application/pdf, etc., based on the file.

// ✅ Summary Table:
// Code	What it does
// Paths.get().resolve()	Creates full file path
// new UrlResource()	Prepares file for download
// exists() && isReadable()	Checks if file is safe to send
// ResponseEntity.ok().body()	Sends file to browser


// =================================================================================
// =================================================================================
// =================================================================================
// =================================================================================

// ✅ URI stands for: Uniform Resource Identifier
// 🧠 Definition:
// A URI is a string that uniquely identifies a resource — it could be a web page, a file, an email address, or even a local file on your computer.

// ✅ Examples of URIs:
// Type	Example URI
// URL	https://www.example.com/about → A web page
// File URI	file:///C:/Users/Upendra/images/photo.jpg → A file on your system
// Mail URI	mailto:upendra@example.com → An email address
// FTP URI	ftp://ftp.example.com/file.txt → A file on an FTP server

// ✅ In Your Case (Spring Boot):
// When you do:

// java
// Copy
// Edit
// file.toUri()
// You're converting a Path (like uploads/myfile.jpg) to a URI like:

// perl
// Copy
// Edit
// file:///C:/projects/uploads/myfile.jpg
// This is used to create a URL resource that Spring Boot can send to the browser.

// ✅ Difference Between URI and URL:
// Every URL is a URI ✅

// But not every URI is a URL ❌

// URI	URL?	Notes
// file:///C:/photo.jpg	No	Not a web address
// https://example.com	Yes	A URI and a URL
// mailto:test@mail.com	No	URI for email, not a webpage

// ✅ Summary:
// Term	Meaning
// URI	A unique identifier for any resource (file, web page, email)
// URL	A specific kind of URI — it’s used to locate resources on the web
