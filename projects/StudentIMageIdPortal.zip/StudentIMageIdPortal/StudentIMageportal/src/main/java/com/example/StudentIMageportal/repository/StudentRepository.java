package com.example.StudentIMageportal.repository;

// Directory: com.example.studentdashboard.repository


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.StudentIMageportal.model.Student;

public interface StudentRepository extends JpaRepository<Student, Long> {
}
