package com.example.StudentIMageportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentIMageportalApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentIMageportalApplication.class, args);
	}

}
