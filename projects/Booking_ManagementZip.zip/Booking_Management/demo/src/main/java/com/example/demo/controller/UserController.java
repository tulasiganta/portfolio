
package com.example.demo.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Users;
import com.example.demo.repository.UserRepository;

import jakarta.servlet.http.HttpSession;

@RestController
@CrossOrigin(origins = "http://localhost:5173", allowCredentials = "true")
@RequestMapping("/api/user")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private HttpSession session;

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Users u) {
        Users existingUser = userRepository.findByEmail(u.getEmail());
        if (existingUser != null) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("email already existed");
        }

        userRepository.save(u);
        return ResponseEntity.status(HttpStatus.CREATED).body("registration done successfully");
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Users u) {
        Users existingUser = userRepository.findByEmail(u.getEmail());

        if (existingUser != null && existingUser.getPassword().equals(u.getPassword())) {
            session.setAttribute("loggedInUser", existingUser.getId());
            Map<String,String> response=new HashMap<>();
            response.put("role",existingUser.getRole());
            response.put("email",existingUser.getEmail());

            return ResponseEntity.ok(response);
        }

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("invalid username or password");
    }
}