package com.example.demo.repository;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Driver;

public interface DriverRepository extends JpaRepository<Driver,Integer> {
    List<Driver> findByCabTypeAndAvailable(String cabType,boolean status);

}
